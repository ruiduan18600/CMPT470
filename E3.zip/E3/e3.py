#!/usr/bin/python3

# Import modules for CGI handling 
import cgitb, cgi
cgitb.enable()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>E3</title>
</head>
<body>
  <form name="e3_form" action="e3.py" method="POST">
    <input type="hidden" name="check_submit" value="1" />
    <label for="userid">Your sfu id: </label>
    <input type="text" name="userid" />
    <br>
    <label for="subject">Email subject</label>
    <input type="text" name="subject" value=""> 
    <br>

    <input class="button" type="submit" value="Submit">
    <input class="button" type="reset" value="Rest">

  </form>
  
</body>
</html>
"""
)

# Create instance of FieldStorage 
form = cgi.FieldStorage()


# Get data from fields
userid = form.getvalue('userid')
subject  = form.getvalue('subject')

print("Content-type:text/html\r\n\r\n")
print("<html>")
print("<head>")
print("<title>Checkbox - Third CGI Program</title>")
print("</head>")
print("<body>")
print("userid: ", userid)
print("subject: ",subject)
print("</body>")
print("</html>")